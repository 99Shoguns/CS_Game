#ifndef BASEBALLPLAYER_H
#define BASEBALLPLAYER_H

#include <string>
using namespace std;

enum Position { Pitcher = 1, Catcher, First, Second, Third,
    Shortstop, LeftField, CenterField, RightField, DesignatedHitter };

class BaseballPlayer
{
private:
    string Name;
public:
    BaseballPlayer();
    BaseballPlayer(string name, Position pos);
    string GetName();
    Position GetPos();
};

#endif