#ifndef BASEBALLTEAM_H
#define BASEBALLTEAM_H

#include <string>
#include "baseballPlayer.h"
using namespace std;

BaseballPlayer Players[12];

class BaseballTeam
{
private:
    string TeamName;
    int PlayerCount = 0;
    int PlayersAtPos[];/* [Postion , Number at position] */
    /* (Pitcher = 0, Catcher = 1, First = 2, Second = 3, Third = 4,
    Shortstop = 5, LeftField = 6, CenterField = 7, RightField = 8, DesignatedHiter = 9 */
    
public:
    BaseballTeam(string name);
    int GetPlayerCount();
    void AddPlayer(BaseballPlayer& player);
    BaseballPlayer& GetPlayerWithName(string name);
    int CountPlayersAtPos(Position pos);
    BaseballPlayer& GetPlayerAtPos(Position pos);
};

#endif