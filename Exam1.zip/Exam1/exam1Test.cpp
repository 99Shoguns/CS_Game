#include <iostream>
#include <string>
#include "baseballPlayer.h"
#include "baseballTeam.h"
using namespace std;

int main()
{
    BaseballPlayer players[] = {
    BaseballPlayer("Kyle Seager", Third), BaseballPlayer("Daniel Vogelbach", DesignatedHitter),
    BaseballPlayer("Mitch Haniger", RightField), BaseballPlayer("Mallex Smith", CenterField),
    BaseballPlayer("Shed Long", Second), BaseballPlayer("Dee Gordon", Second),
    BaseballPlayer("Omar Narvaez", Catcher), BaseballPlayer("Domingo Santana", LeftField),
    BaseballPlayer("Felix Hernandez", Pitcher), BaseballPlayer("Marco Gonzalez", Pitcher),
    BaseballPlayer("Justice Sheffield", Pitcher), BaseballPlayer("Mike Leake", Pitcher)
    };
    
    BaseballTeam team("Seattle Mariners");

    int count = sizeof(players)/sizeof(players[0]);
    for (int i=0; i<count; i++)
        team.AddPlayer(players[i]);

    int errors = 0;
    if (team.GetPlayerCount() != count) {
        cout << "Playercount Failed" << endl;
        errors++;
    }

    //Make sure we can find an existing player
    BaseballPlayer bp = team.GetPlayerWithName("Shed Long");
    if (bp.GetName() != "Shed Long") {
        cout << "GetPlayerWithName failed: " << bp.GetName() << endl;
        errors++;
    }

    BaseballPlayer defaultPlayer;
    //This player does not exist, so we should get the default BaseballPlayer
    bp = team.GetPlayerWithName("Does Not Exist");
    if (bp.GetName() != defaultPlayer.GetName()) {
        cout << "GetPlayerWithName with wrong name failed: " << bp.GetName() << endl;
        errors++;
    }

    if (team.CountPlayersAtPos(Pitcher) != 4) {
        cout << "CountPlayersAtPos failed: " << team.CountPlayersAtPos(Pitcher) << endl;
        errors++;
    }

    //Make sure we can find an existing player
    bp = team.GetPlayerAtPos(Catcher);
    if (bp.GetName() != "Omar Narvaez" && bp.GetPos() != Catcher) {
        cout << "GetPlayerAtPos failed: " << bp.GetName() << endl;
        errors++;
    }

    //This player does not exist, so we should get the default BaseballPlayer
    bp = team.GetPlayerAtPos(Shortstop);
    if (bp.GetName() != defaultPlayer.GetName()) {
        cout << "GetPlayerAtPosition with invalid position failed: " << bp.GetName() << endl;
        errors++;
    }

    if (errors == 0) {
        cout << "Tests passed!\n";
    }
    
    return 0;
}