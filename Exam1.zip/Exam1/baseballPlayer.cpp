/*
I affirm that all code given below was writen solely by me,
Garret O'Shaughnessy, and that any help I received adhered
to the rules stated for this exam.
*/
#include <iostream>
#include <string>
#include "baseballPlayer.h"
#include "baseballTeam.h"
using namespace std;

BaseballPlayer::BaseballPlayer()
{
    Name = "John Doe";
    Position {Catcher};
}
BaseballPlayer::BaseballPlayer(string name, Position pos)
{
    Name = name;
    Position {pos};
}
string BaseballPlayer::GetName()
{
    return Name;
}
Position BaseballPlayer::GetPos()
{
    return Position {};
}