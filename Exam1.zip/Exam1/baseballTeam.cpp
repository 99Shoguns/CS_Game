/*
I affirm that all code given below was writen solely by me,
Garret O'Shaughnessy, and that any help I received adhered
to the rules stated for this exam.
*/
#include <iostream>
#include <string>
#include "baseballTeam.h"
#include "baseballPlayer.h"
using namespace std;
int i = 0;
BaseballTeam::BaseballTeam(string name)
{
    TeamName = name;
}
int BaseballTeam::GetPlayerCount()
{
    return PlayerCount;
}
void BaseballTeam::AddPlayer(BaseballPlayer& player)
{
    Players[i] = player;
    PlayerCount++;
    i++;
}
BaseballPlayer& BaseballTeam::GetPlayerWithName(string name)//Can't get to work
{
    string test;
    for (int x = 0; x < 12; x++){
        test = Players[x].GetName();
        if (test.find("name") != string::npos)
            return BaseballPlayer::GetName();
    }
    return BaseballPlayer::GetName();   
}
BaseballPlayer& BaseballTeam::GetPlayerAtPos(Position pos)//Can't get to work
{
    for (int x = 0; x < 12; x++){
        Players[x];
        if (BaseballPlayer::GetPos() == pos)
            return Players[x];
    }
    return BaseballPlayer::GetPos();
}