#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    int count = 0;
    //Prompt for file name
    cout << "Please enter a file name.\n";
    string file;
    cin >> file;
    //Create input file stream and open it
    ifstream fin(file, ios::in);
    //Check if file opens or fails to open
    if (fin.fail()){
        cout << "Error opening file!";
        return 0;
    }
    //Make a string line and a char variable
    string line;
    char ch;
    //While not at end of file, count characters per line and add to count
    while (getline(fin,line)){
        ch = line.length();//Set char to the length of the line
        count += ch;//Count increases by char size
    }
    cout << "There are " << count << " characters in this file.\n";
    //Close file
    fin.close();

    return 0;
}