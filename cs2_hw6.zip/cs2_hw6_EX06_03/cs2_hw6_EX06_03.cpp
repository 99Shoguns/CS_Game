#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(){
    int year;
    char gender;
    string name;

    cout << "Please enter a year.\n";
    cin >> year;
    cout << "Please enter a gender (M or F).\n";
    cin >> gender;
    cout << "Please enter a name.\n";
    cin >> name;
    //Make filename with year entered
    string syear = to_string(year);
    string file = "Babynameranking" + syear + ".txt";

    //Create input file stream with custom year and open it
    ifstream fin;
    fin.open(file);

    //Create string line to search with
    string line;
    int rank = 1;
    string tab = "\t";
    //Search whole file until end or name is found
    while (getline(fin,line)){
        size_t found = line.find(name);
        //Find name after 3 tabs if gender is Female
        if (gender == 'F'){
            for (int i=0; i<3; i++){
                found = line.find(tab);
                if (found != line.npos){
                    found = line.find(tab, found+1);
                }
            } 
            found = line.find(name, found);
        }
        if ((found != line.npos) && (gender == 'M')){//Search if Male
            cout << name << " is ranked #" << rank << " in year " << year << ".\n";
            fin.close();
            return 0;
        }
        else if ((found != line.npos) && (gender == 'F')){//Search if Female
            cout << name << " is ranked #" << rank << " in year " << year << ".\n";
            fin.close();
            return 0;
        }
        rank++;
    }
    cout << "The name " << name << " is not ranked in year " << year << ".\n";
    fin.close();

    return 0;
}