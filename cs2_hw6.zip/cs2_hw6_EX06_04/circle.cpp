#include "circle.h"

int Circle::numberOfObjects = 0;

Circle::Circle()
{
    radius = 1;
    numberOfObjects++;
}
Circle::Circle(double d)
{
    radius = d;
    numberOfObjects++;
}
double Circle::getArea() const
{
    return (radius * radius * 3.14159);
}
double Circle::getRadius() const
{
    return radius;
}
void Circle::setRadius(double d)
{
    radius = (d >= 0) ? d : 0;
}
int Circle::getNumberOfObjects()
{
    return numberOfObjects;
}
