#include "circle.h"
#include <iostream>
#include <string>
using namespace std;

bool operator<(const Circle &c1, const Circle &c2);
bool operator<=(const Circle &c1, const Circle &c2);
bool operator==(const Circle &c1, const Circle &c2);
bool operator!=(const Circle &c1, const Circle &c2);
bool operator>(const Circle &c1, const Circle &c2);
bool operator>=(const Circle &c1, const Circle &c2);

int main(){
    Circle circle1(16);
    Circle circle2(20);
    Circle circle3(6);
    Circle circle4(10);
    Circle ocircle1, ocircle2, ocircle3, ocircle4;
    for (int i=0; i<4; i++){
        //Sort first 2
        if (circle1 <= circle2){
            ocircle1 = circle1;
            ocircle2 = circle2;
        }
        else {
            ocircle1 = circle2;
            ocircle2 = circle1;
        }
        //Sort first 3
        if (circle3 <= ocircle1){
            ocircle3 = ocircle2;
            ocircle2 = ocircle1;
            ocircle1 = circle3;
        }
        else if (circle3 >= ocircle1 && circle3 <= ocircle2) {
            ocircle3 = ocircle2;
            ocircle2 = circle3;
        }
        else {
            ocircle3 = circle3;
        }
        //Sort all 4
        if (circle4 <= ocircle1){
            ocircle4 = ocircle3;
            ocircle3 = ocircle2;
            ocircle2 = ocircle1;
            ocircle1 = circle4;
        }
        else if (circle4 >= ocircle1 && circle4 <= ocircle2) {
            ocircle4 = ocircle3;
            ocircle3 = ocircle2;
            ocircle2 = circle4;
        }
        else if (circle4 >= ocircle2 && circle4 <= ocircle3){
            ocircle4 = ocircle3;
            ocircle3 = circle4;
        }
        else {
            ocircle4 = circle4;
        }
    }
    double r1, r2, r3, r4, or1, or2, or3, or4;
    r1 = circle1.getRadius();
    r2 = circle2.getRadius();
    r3 = circle3.getRadius();
    r4 = circle4.getRadius();
    or1 = ocircle1.getRadius();
    or2 = ocircle2.getRadius();
    or3 = ocircle3.getRadius();
    or4 = ocircle4.getRadius();

    cout << "The unordered circle radii are: " << r1 << ", " << r2 << ", " << r3 << ", and " << r4 << ".\n";
    cout << "The ordered circle radii are: " << or1 << ", " << or2 << ", " << or3 << ", and " << or4 << ".\n";
}

bool operator<(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 < r2);
}
bool operator<=(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 <= r2);
}
bool operator==(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 == r2);
}
bool operator!=(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 != r2);
}
bool operator>(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 > r2);
}
bool operator>=(const Circle &c1, const Circle &c2)
{
    double r1 = c1.getRadius();
    double r2 = c2.getRadius();
    return (r1 >= r2);
}