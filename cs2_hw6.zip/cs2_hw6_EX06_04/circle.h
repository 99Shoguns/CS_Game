#ifndef CIRCLE_H
#define CIRCLE_H

class Circle
{
private:
    double radius;
    static int numberOfObjects;
public:
    Circle();
    Circle(double d);
    double getArea() const;
    double getRadius() const;
    void setRadius(double d);
    static int getNumberOfObjects();
};

#endif