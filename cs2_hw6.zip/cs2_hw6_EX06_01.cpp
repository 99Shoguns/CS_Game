#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main() {
    //Create output file stream and open it
    ofstream fout("Exercise13_1.text", ios::app);
    //If file can't open, exit program and display error
    if (fout.fail()){
        cout << "Error opening file!\n";
        return 0;
    }
    //Create a line object and random seed
    int line;
    srand(time(NULL));
    
    for (int i=1; i<=100; i++){
        //Make a random int and output to file.
        int r1 = rand();
        fout << "#" << i << ": " << r1 << endl;
    }
    fout.close();
    cout << "Done.\n";

    return 0;
}