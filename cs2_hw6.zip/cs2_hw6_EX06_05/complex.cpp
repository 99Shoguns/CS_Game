#include "complex.h"
#include <sstream>
#include <string>
#include <iostream>
#include <cmath>
using namespace std;

/* I used the Liang book companion website for a walkthrough of this problem and to check my
work with how the video does it to make sure I am understanding the content. I have annotated
in this code where I used exact references to what the companion website video used. */

Complex::Complex()
{
    a = 0;
    b = 0;
}
Complex::Complex(double a)
{
    this->a = a;
    b = 0;
}
Complex::Complex(double a, double b)
{
    this->a = a;
    this->b = b;
}
double Complex::getA() const
{
    return a;
}
double Complex::getB() const
{
    return b;
}
double Complex::abs() const
{
    // |a + bi| = sqrt((a*a + b*b))
    return (sqrt(a*a + b*b));
}
Complex Complex::add(const Complex &c) const
{
    //(a + bi) + (c + di) = (a + c) + (b + d)i
    double aa = a + c.getA();//a + c
    double bb = b + c.getB();//b + d
    return Complex(aa, bb);
}
Complex Complex::subtract(const Complex &c) const
{
    //(a + bi) - (c + di) = (a - c) + (b - d)i
    double aa = a - c.getA();//a - c
    double bb = b - c.getB();//b - d
    return Complex(aa, bb);
}
Complex Complex::multiply(const Complex &cplx) const
{
    //(a + bi) * (c + di) = (a*c - b*d) + (b*c + a*d)i
    double c = cplx.getA();
    double d = cplx.getB();
    double aa = ((a * c) - (b * d));//(a*c - b*d)
    double bb = ((b * c) + (a * d));//(b*c + a*d)
    return Complex(aa, bb);
}
Complex Complex::divide(const Complex &cplx) const
{
    //(a + bi) / (c + di) = ((a*c + b*d) / (c*c + d*d)) + ((b*c - a*d)i / (c*c + d*d))
    double c = cplx.getA();
    double d = cplx.getB();
    double aa = ((a*c + b*d) / (c*c + d*d));
    double bb = ((b*c - a*d) / (c*c + d*d));
    return Complex(aa, bb);
}
string Complex::toString() const
{
    //***Obtained from Liang book companion website***//
    stringstream ss;
    ss << a;
    if (b != 0)
        ss << " + " << b << "i";
    return ss.str();
    //***Obtained from Liang book companion website***//
}
string Complex::getRealPart() const
{
    stringstream ss;
    ss << a;
    return ss.str();
}
string Complex::getImaginaryPart() const
{
    stringstream ss;
    if (b != 0)
        ss << b << "i";
    return ss.str();
}


/*** Obtained how to overload +=, -=, *=, and /= operators from stack overflow at:
https://stackoverflow.com/questions/4581961/c-how-to-overload-operator ***/
Complex &Complex::operator+=(const Complex &c)
{
    *this = add(c);//value of this pointer = add(c)
    return *this;//return the value of this pointer
}
Complex &Complex::operator-=(const Complex &c)
{
    *this = subtract(c);//value of this pointer = subtract(c)
    return *this;//return the value of this pointer
}
Complex &Complex::operator*=(const Complex &c)
{
    *this = multiply(c);//value of this pointer = multiply(c)
    return *this;//return the value of this pointer
}
Complex &Complex::operator/=(const Complex &c)
{
    *this = divide(c);//value of this pointer = divide(c)
    return *this;//return the value of this pointer
}
/***Obtained how to overload +=, -=, *=, and /= operators from stack overflow at:
https://stackoverflow.com/questions/4581961/c-how-to-overload-operator ***/


double &Complex::operator[](const int &index)
{
    if (index == 0){
        return a;
    }
    else if (index == 1){
        return b;
    }
    else {
        throw runtime_error("Error! Index given is not 0 or 1!");
    }
    //runtime_error usage obtained from:
    //https://stackoverflow.com/questions/26171631/throwing-a-run-time-error
}
Complex Complex::operator++()//Prefix (++a)
{
    //Determined by looking at usage of '*this' from the += operator that was referenced from website
    a++;//Incremenet the real number separate from the 'i' by one
    return *this;//Return the value of the pointer
}
Complex Complex::operator--()//(++a)
{
    a--;//Increment the real number separate from the 'i' by one
    return *this;//Return the value of the pointer
}


//***Obtained from Liang book companion website***//
Complex Complex::operator++(int dummy)//Postfix (a++)
{
    Complex temp(a, b);//Create a temporary Complex object to return with old values
    a++;
    return temp;
}
Complex Complex::operator--(int dummy)//(a++)
{
    Complex temp(a, b);//Create a temporary Complex object to return with old values
    a++;
    return temp;
}
ostream &operator<<(ostream &s, const Complex &c)
{
    s << c.toString();
    return s;//***Obtained from Liang book companion website***//
}
istream &operator>>(istream &s, const Complex &c)
{
    cout << "Enter a: ";
    s >> c.a;
    
    cout << "Enter b: ";
    s >> c.b;
    return s;//***Obtained from Liang book companion website***//
}
Complex Complex::operator+()
{
    return *this;
}
Complex Complex::operator-()
{
    a *= -1;//Make 'a' negative
    return *this;
}
//***Obtained from Liang book companion website***//


//Non-Member Functions
Complex operator+(const Complex &c1, const Complex &c2)
{
    return c1.add(c2);
}
Complex operator-(const Complex &c1, const Complex &c2)
{
    return c1.subtract(c2);
}
Complex operator*(const Complex &c1, const Complex &c2)
{
    return c1.multiply(c2);
}
Complex operator/(const Complex &c1, const Complex &c2)
{
    return c1.divide(c2);
}