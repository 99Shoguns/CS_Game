#ifndef COMPLEX_H
#define COMPLEX_H

#include <string>
using namespace std;

class Complex
{
private:
    double a;
    double b;
public:
    Complex();
    Complex(double a);
    Complex(double a, double b);
    double getA() const;
    double getB() const;
    double abs() const;
    Complex add(const Complex &c) const;
    Complex subtract(const Complex &c) const;
    Complex multiply(const Complex &c) const;
    Complex divide(const Complex &c) const;
    string toString() const;
    string getRealPart() const;
    string getImaginaryPart() const;
    Complex &operator+=(const Complex &c);
    Complex &operator-=(const Complex &c);
    Complex &operator*=(const Complex &c);
    Complex &operator/=(const Complex &c);
    double &operator[](const int &index);
    Complex operator++();//Prefix
    Complex operator--();
    //***Obtained from Liang book companion website***//
    Complex operator++(int dummy);//Postfix
    Complex operator--(int dummy);
    friend ostream &operator<<(ostream &s, const Complex &c);
    friend istream &operator>>(istream &s, const Complex &c);
    //***Obtained from Liang book companion website***//
    Complex operator+();
    Complex operator-();
};

Complex operator+(const Complex &c1, const Complex &c2);
Complex operator-(const Complex &c1, const Complex &c2);
Complex operator*(const Complex &c1, const Complex &c2);
Complex operator/(const Complex &c1, const Complex &c2);

#endif