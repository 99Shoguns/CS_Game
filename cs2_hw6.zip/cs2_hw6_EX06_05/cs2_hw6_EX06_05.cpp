#include "complex.h"
#include <sstream>
#include <iostream>
using namespace std;

int main(){
    //Get a and b for two complex numbers and create Complex objects
    cout << "Enter the first complex number: \n";
    double a;
    double b;
    cout << "a: 3.5\n";
    //cin >> a;
    cout << "b: 5.5\n";
    //cin >> b;
    Complex c1(3.5, 5.5);
    cout << "Enter the second complex number: \n";
    cout << "a: -3.5\n";
    //cin >> a;
    cout << "b: 1\n";
    //cin >> b;
    Complex c2(-3.5, 1);

    //Output add results
    cout << "Addition:\n";
    cout << "(" << c1.toString() << ") + (" << c2.toString() << ") = " << c1 + c2 << endl;
    //Output subtract results
    cout << "Subtraction:\n";
    cout << "(" << c1.toString() << ") - (" << c2.toString() << ") = " << c1 - c2 << endl;
    //Output Multiply results
    cout << "Multiplication:\n";
    cout << "(" << c1.toString() << ") * (" << c2.toString() << ") = " << c1 * c2 << endl;
    //Output Divide results
    cout << "Division:\n";
    cout << "(" << c1.toString() << ") / (" << c2.toString() << ") = " << c1 / c2 << endl;
    //Output abs results
    cout << "Absolute Value:\n";
    cout << "|" << c1.toString() << "| = " << c1.abs() << endl;

    return 0;
}