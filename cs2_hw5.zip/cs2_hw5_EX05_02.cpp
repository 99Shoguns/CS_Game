#include <iostream>
#include <string>
using namespace std;

template <typename T>
bool isSorted(const T list[], int size){
    bool sorted;
    for (int i = 0; i < size - 1; i++){
        int j = i+1;
        if (list[i] > list[j]){
            return false;
        }
    }
    return true;
}

int main(){
    int intarray[5] = {5, 1, 4, 3, 2};
    double doublearray[5] = {1.6, 2.7, 3.8, 4.8, 5.9};
    string stringarray[5] = {"abc", "bcd", "cde", "efg", "hij"};

    cout << "Is intarray sorted? : " << isSorted(intarray, 5) << endl;//Not sorted
    cout << "Is doublearray sorted? : " << isSorted(doublearray, 5) << endl;//Sorted
    cout << "Is stringarray sorted? : " << isSorted(stringarray, 5) << endl;//Sorted

    return 0;
}