#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

template <typename T>
void shuffle(vector<T>& v){
    T temp;
    srand(time(0));
    int r1 = rand() % v.size();
    for (int i=0; i<v.size(); i++){
        r1 = rand() % v.size();
        temp = v.at(r1);
        v.at(r1) = v.at(i);
        v.at(i) = temp;
    }
}

int main(){

    vector<int> v1;
    cout << "The current v1 values are: \n";
    for (int i=0; i<10; i++){
        v1.push_back(i);
        cout << v1.at(i) << endl;
    }
    cout << endl;

    cout << "**shuffle**\n\n";

    shuffle(v1);
    cout << "The new v1 values are: \n";
    for (int i=0; i<10; i++){
        cout << v1.at(i) << endl;
    }

    return 0;
}