#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main(){
    
    vector<int> v1;
    vector<int> v2(5);
    vector<int> v3(5, 0);
    cout << "***Test of push_back(elementType) v1:\n";
    cout << "The new contents of v1 are: \n";
    for (int i=0; i<5; i++){
        v1.push_back(i);
        cout << v1.at(i) << endl;
    }
    cout << endl;

    cout << "***Test of size(): \n";
    cout << "The size of v1 is: " << v1.size() << endl;
    cout << "The size of v2 is: " << v2.size() << endl;
    cout << "The size of v3 is: " << v3.size() << endl << endl;

    cout << "***Test of pop_back(): \n";
    cout << "The new contents of v1 are: \n";
    v1.pop_back();
    for (int i=0; i<v1.size(); i++){
        cout << v1[i] << endl;
    }
    cout << "The size of v1 is: " << v2.size() << endl << endl;

    cout << "***Test of at(index): \n";
    cout << "The v2 element at index 3 is: " << v2.at(3) << endl << endl;

    cout << "***Test of empty(): \n";
    cout << "Is v1 empty? : " << v1.empty() << endl << endl;

    cout << "***Test of clear(): \n";
    cout << "The contents of v1 are: \n";
    for (int i=0; i < v1.size(); i++){
        cout << v1.at(i) << endl;
    }
    cout << "**Clear v1**\n";
    v1.clear();
    cout << "The contents of v1 are: \n";
    for (int i=0; i < v1.size(); i++){
        cout << v1.at(i) << endl;
    }
    cout << "The size of v1 is: " << v1.size() << endl << endl;

    cout << "***Test of swap(vector): \n";
    cout << "The contents of v1 are: \n";
    for (int i=0; i < v1.size(); i++){
        cout << v1.at(i) << endl;
    }
    cout << "The contents of v3 are: \n";
    for (int i=0; i < v3.size(); i++){
        cout << v3.at(i) << endl;
    }
    cout << "**Swap contents**\n";
    v1.swap(v3);
    cout << "The contents of v1 are: \n";
    for (int i=0; i < v1.size(); i++){
        cout << v1.at(i) << endl;
    }
    cout << "The contents of v3 are: \n";
    for (int i=0; i < v3.size(); i++){
        cout << v3.at(i) << endl;
    }

    return 0;
}