#include <iostream>
#include <string>
using namespace std;

template <typename T>
int linearSearch(const T list[], T key, int arraySize){
    for (int i=0; i<arraySize; i++){
        if (key == list[i]){
            return i;
        }
    }
    return -1;
}

int main(){
    //Arrays to test.
    int intarray[5] = {1, 2, 3, 4, 5};
    double doublearray[5] = {1.5, 2.6, 3.7, 4.8, 5.9};
    string stringarray[5] = {"one", "two", "three", "four", "five"};
    string key = "five"; //variable to test for string key.

    //Test the arrays with the template function.
    cout << "The index of '3' is: " << linearSearch(intarray, 3, 5) << endl;
    cout << "The index of '4.8' is: " << linearSearch(doublearray, 4.8, 5) << endl;
    cout << "The index of \"five\" is: " << linearSearch(stringarray, key, 5) << endl;
    //Test output of key that isn't in array.
    cout << "The index of '8' is: " << linearSearch(intarray, 8, 5) << endl;
    
    return 0;
}