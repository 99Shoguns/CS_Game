#include <iostream>
#include <string>
#include "date.h"
#include "account.h"
using namespace std;
Account _default;
int main(){

    Account myAccount("George", 1122, 1000);
    _default.setApr(1.5);
    myAccount.deposit(30);
    myAccount.deposit(40);
    myAccount.deposit(50);
    myAccount.withdraw(5);
    myAccount.withdraw(4);
    myAccount.withdraw(2);
    cout << "Account Summary: \n";
    cout << "- Account Holder Name: " << myAccount.getName() << ".\n";
    cout << "- Interest Rate: " << myAccount.getApr() << "%.\n";
    cout << "- Balance: $" << myAccount.balance() << ".\n";
    cout << "- Transactions: ";
    

    return 0;
}