#include "date.h"
#include <ctime>
#include <iostream>
using namespace std;

Date::Date()
{
    int totalSeconds = time(0);
    int totalMinutes = totalSeconds / 60;
    int totalHours = totalMinutes / 60;
    int totalDays = totalHours / 24;
    int currentDay = ((totalHours / 24) % 30);
    int currentMonth = ((totalDays / 30) % 12);
    int currentYear = ((totalDays / 365) + (1970));
    if(currentMonth == 1)
        this->month = "Jan";
    else if(currentMonth == 2)
        this->month = "Feb";
    else if(currentMonth == 3)
        this->month = "Mar";
    else if(currentMonth == 4)
        this->month = "Apr";
    else if(currentMonth == 5)
        this->month = "May";
    else if(currentMonth == 6)
        this->month = "Jun";
    else if(currentMonth == 7)
        this->month = "Jul";
    else if(currentMonth == 8)
        this->month = "Aug";
    else if(currentMonth == 9)
        this->month = "Sep";
    else if(currentMonth == 10)
        this->month = "Oct";
    else if(currentMonth == 11)
        this->month = "Nov";
    else 
        this->month = "Dec";
    year = currentYear;
    day = currentDay;
}
Date::Date(int time)
{
    int totalSeconds1 = time;
    int totalMinutes1 = totalSeconds1 / 60;
    int totalHours1 = totalMinutes1 / 60;
    int totalDays1 = totalHours1 / 24;
    int currentDay1 = ((totalHours1 / 24) % 30);
    int currentMonth1 = ((totalDays1 / 30) % 12);
    int currentYear1 = totalDays1 % 365;
    year = currentYear1;
    switch (currentMonth1)
    {
        case 1: this->month = "Jan";
            break;
        case 2: this->month = "Feb";
            break;
        case 3: this->month = "Mar";
            break;
        case 4: this->month = "Apr";
            break;
        case 5: this->month = "May";
            break;
        case 6: this->month = "Jun";
            break;
        case 7: this->month = "Jul";
            break;
        case 8: this->month = "Aug";
            break;
        case 9: this->month = "Sep";
            break;
        case 10: this->month = "Oct";
            break;
        case 11: this->month = "Nov";
            break;
        case 12: this->month = "Dec";
    }
    day = currentDay1;
}
Date::Date(int year, string month, int day)
{
    this->year = year;
    this->month = month;
    this->day = day;
}
int Date::getYear()
{
    return year;
}
string Date::getMonth()
{
    return month;
}
int Date::getDay()
{
    return day;
}
void Date::setDate(int elapsedTime)
{
    int totalSeconds2 = elapsedTime;
    int totalMinutes2 = totalSeconds2 / 60;
    int totalHours2 = totalMinutes2 / 60;
    int totalDays2 = totalHours2 / 24;
    int currentDay2 = ((totalHours2 / 24) % 30);
    int currentMonth2 = ((totalDays2 / 30) % 12);
    int currentYear2 = totalDays2 % 365;
    year = currentYear2;
    switch (currentMonth2)
    {
        case 1: this->month = "Jan";
            break;
        case 2: this->month = "Feb";
            break;
        case 3: this->month = "Mar";
            break;
        case 4: this->month = "Apr";
            break;
        case 5: this->month = "May";
            break;
        case 6: this->month = "Jun";
            break;
        case 7: this->month = "Jul";
            break;
        case 8: this->month = "Aug";
            break;
        case 9: this->month = "Sep";
            break;
        case 10: this->month = "Oct";
            break;
        case 11: this->month = "Nov";
            break;
        case 12: this->month = "Dec";
    }
    day = currentDay2;
}