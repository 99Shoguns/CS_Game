#include "account.h"
#include "transaction.h"
#include <string>
#include <vector>
#include <iostream>
using namespace std;

Account::Account()
{
    name = "John Doe";
    id = id++;
    balance = 0.00;
    annualInterestRate = 1.5;
}
Account::Account(string name, int id, double balance)
{
    this->name = name;
    this->id = id;
    this->balance = balance;
}
int Account::getId() const
{
    return id;
}
void Account::setId(int newId)
{
    id = newId;
}
double Account::getBalance() const
{
    return balance;
}
void Account::setBalance(double newBalance)
{
    balance = newBalance;
}
double Account::getApr() const
{
    return annualInterestRate;
}
void Account::setApr(double newApr)
{
    annualInterestRate = newApr;
}
double Account::getMonthlyInterestRate() const
{
    return (annualInterestRate / 12);
}
void Account::withdraw(double amount)
{
    balance -= amount;
    transactions.push_back('W', amount, getBalance(), "Withdrawl");

}
void Account::deposit(double amount)
{
    balance += amount;
    transactions.push_back('D', amount, getBalance(), "Deposit")
}