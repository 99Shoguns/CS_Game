#include "transaction.h"
#include <string>
#include <iostream>
using namespace std;

Transaction::Transaction(char type, double amount, double balance, string description)
{
    this->type = type;
    this->amount = amount;
    this->balance = balance;
    this->description = description;
}
