#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>
#include <vector>
#include <iostream>
#include "transaction.h"
using namespace std;

static double annualInterestRate;
class Account
{
private:
    int id = 0;
    string name;
    double balance;
    vector<Transaction> transactions;
public:
    Account();
    Account(string name, int id, double balance);
    int getId() const;
    void setId(int newId);
    double getBalance() const;
    void setBalance(double newBalance);
    double getApr() const;
    void setApr(double newApr);
    double getMonthlyInterestRate() const;
    void withdraw(double amount);
    void deposit(double amount);
};

#endif