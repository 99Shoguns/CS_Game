#ifndef DATE_H
#define DATE_H

#include <string>
#include <ctime>
#include <iostream>
using namespace std;

class Date
{
private:
    int year;
    string month;
    int day;
public:
    Date();
    Date(int time);
    Date(int year, string month, int day);
    int getYear();
    string getMonth();
    int getDay();
    void setDate(int elapseTime);
};

#endif