//ex05
#include <iostream>
using namespace std;

void listArray(int array[], int size){
    for (int i = 0; i < size; i++){
        cout << "#" << (i+1) << ": " << array[i] << endl;
    }
}

void checkArray(int array[], int size){
    cout << "Please pick a number.\n";
    int ans;
    cin >> ans;
    for (int i = 0; i < size; i++){
        if (ans == array[i]){
            cout << "The array contains that number at index " << i << endl;
            i = size;
        }
        else if (ans != array[i] && (i == size-1))
            cout << "The array does not contain that number.\n";
    }
}

void ex05(){
    //part a
    int five[5];
    for (int i = 0; i < 5; i++){
        cout << "Please pick 5 integers: \n#" << (i + 1) << ": ";
        cin >> five[i];
        cout << endl;
    }
    
    //part b
    int sum = five[0];
    int product = five[0];
    for (int i = 1; i < 5; i++){
        sum = sum + five[i];
    }
    for (int i = 1; i < 5; i++){
        product = product * five[i];
    }
    cout << "The sum of the numbers is: " << sum << ".\n";
    cout << "The product of the numbers is: " << product << ".\n";

    //part c
    listArray(five, 5);

    //part d
    checkArray(five, 5);


}

int main(){

    ex05();

    return 0;
}