//EX01_02
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void ex02(){
    //part a
    bool hasPassedTest = true;

    //part b
    srand(time(0));
    int x = rand();
    int y = rand();
    if (x >= y)
        cout << "x is >= y.\n";
    else
        cout << "x is NOT >= y.\n";
    
    //part c
    int numberOfShares;
    cout << "Please input a number of shares: ";
    cin >> numberOfShares;
    if (numberOfShares < 100)
        cout << "That number is less than 100.\n";
    else
        cout << "That number is NOT less than 100.\n";

    //part d
    cout << "Please give the width of a box.\n";
    int boxWidth;
    cin >> boxWidth;
    cout << "Please give the width of a book.\n";
    int bookWidth;
    cin >> bookWidth;
    if (boxWidth % bookWidth == 0)
        cout << "The box width is evenly divisible by the book width.\n";
    else
        cout << "The box width is NOT evenly divisibly by the book width.\n";
    
    //part e
    int shelfLife, temperature;
    cout << "Please give the shelf life of a box of chocolate.\n";
    cin >> shelfLife;
    cout << "Please give the temperature outside.\n";
    cin >> temperature;
    if (temperature > 90)
        shelfLife = shelfLife - 4;
}

int main(){

    ex02();

    return 0;
}