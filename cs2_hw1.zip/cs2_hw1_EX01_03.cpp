//EX01_03
#include <iostream>
#include <cmath>
#include <string>
using namespace std;

void ex03(){
    //part a
    int area;
    cout << "Please input the area of a square.\n";
    cin >> area;
    double s = sqrt(area);
    double d = s * sqrt(2);
    cout << "The diagonal of the square is " << d << endl;

    //part b
    char answer;
    cout << "Give me a yes or no (y or n).\n";
    cin >> answer;
    if (answer == 'y')
        cout << "yes\n";
    else if (answer == 'n')
        cout << "no\n";
        cin.ignore(256, '\n');

    //part c
    char tab = '\t';

    //part d
    string mailingAddress;
    cout << "Give me your mailing address (Don't worry about suspicious packages...).\n";
    getline(cin,mailingAddress);

    //part e
    string x = "";
}

int main(){

    ex03();

    return 0;
}