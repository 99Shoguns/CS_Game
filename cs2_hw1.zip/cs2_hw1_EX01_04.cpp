//ex04
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

int x2(int num){
    num = num * 2;
    return num;
}

int add(int num1, int num2){
    int sum = num1 + num2;
    return sum;
}

int addPar(int& p){
    p++;
    return p;
}

void ex04(){
    //part a
    cout << "Please input a number between 1 and 10.\n";
    int ans;
    cin >> ans;
    while (ans < 1 || ans > 10){
        cout << "That is an invalid number. Please input a number between 1 and 10.\n";
        cin >> ans;
    }
    cout << endl;

    //part b
    int sum  = 0;
    for (int i = 1; i <= ans; i++){
        sum += pow(i , 3);
    }
    cout << sum << endl << endl;

    //part c
    int z = 0;
    do {
        cout << "*";
        z++;
    }
    while (z < ans);
    cout << endl << endl;

    //part d
    for (int i = 0; i <= 40; i++){
        if (i % 2 == 0)
            cout << i << endl;
    }
    cout << endl;

    //part e
    cout << x2(ans) << endl << endl;

    //part f
    srand(time(0));
    int num1 = rand();
    int num2 = rand();
    cout << add(num1, num2) << endl << endl;

    //part g
    int pass = 41;
    cout << addPar(pass) << endl;




}

int main(){

    ex04();

    return 0;
}