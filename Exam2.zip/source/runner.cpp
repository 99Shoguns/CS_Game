/* I affirm that all code given below was written solely by me, Garrett O'Shaughnessy, 
and that any help I received adhered to the rules stated for this exam. */

#include "runner.h"
#include <string>
using namespace std;

Runner::Runner(string FirstName, string LastName, int Pace)
{
    this->FirstName = FirstName;
    this->LastName = LastName;
    this->Pace = Pace;
}
string Runner::getFirstName() const
{
    return FirstName;
}
string Runner::getLastName() const
{
    return LastName;
}
int Runner::getPace() const
{
    return Pace;
}