/* I affirm that all code given below was written solely by me, Garrett O'Shaughnessy, 
and that any help I received adhered to the rules stated for this exam. */

#include "runner.h"
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

int main(){
    
    //Create modifyiable first and last names, and pace in seconds to make Runners.
    string first, last;
    int seconds;
    //Create vector to store runners in.
    vector<Runner> allRunners;
    //Open registrants file as input.
    ifstream fin;
    fin.open("registrants.txt");
    //Terminate program and ouput error if file can't open.
    if (fin.fail()){
        cout << "Error opening file!\n";
        return 0;
    }
    //Create string line to search with.
    string line;
    
    //**********Search the file and add runners to the vector as Runner objects**********//

    while (getline(fin, line)){//While not at the end of the file
        fin >> first >> last >> seconds;// ">>" operator ignores white space so each variable is separated by spaces.
        Runner temp(first, last, seconds);//Re-usable temp vector
        allRunners.push_back(temp);
    }
    //Make int of vector size.
    int size = allRunners.size();
    //Sort vector based on pace
    //If the lower index's pace is greater than the next higher index's pace, switch them
    for (int i = 0; i < size; i++){
        for (int j = 1; j < size - 1; j++){
            if (allRunners[i].getPace() > allRunners[j].getPace()){
                Runner temp = allRunners[i];
                allRunners[i] = allRunners[j];
                allRunners[j] = temp;
            }
        }
    }
    
    //Vector is inverted. Fixing inversion issue.
    vector<Runner> tempCopy;//Create a temp vector and copy allRunners to it.
    for (int i = 0; i < size; i++){
        tempCopy.push_back(allRunners[i]);
    }
    for (int i = 0; i < size; i++){
        int j = size - (i+1);
        allRunners[i] = tempCopy[j];
    }
    //********Issue with fastest runner indexing********//
    

    fin.close();//Close the registrants.txt file

    cout << "Done making vector.\n";

    //**********Sort runners into color groups**********//
    
    //*****white.txt*****//
    //Create output file stream and open it for white.txt runners (0-360 seconds).
    ofstream fout("white.txt", ios::out);
    //Output error if file can't open.
    if (fout.fail()){
        cout << "Error opening file \"white.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() <= 360){
            //Add Runner to file "white.txt" if pace is <= 360 seconds.
            fout << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    fout.close();//Close the "white.txt" file.

    //*****yellow.txt*****//
    //Create output file stream and open it for yellow.txt runners (361-420 seconds).
    ofstream fouty("yellow.txt", ios::out);
    //Output error if file can't open.
    if (fouty.fail()){
        cout << "Error opening file \"yellow.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 361 && allRunners[i].getPace() <= 420){
            //Add Runner to file "yellow.txt" if pace is from 361-420 seconds.
            fouty << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    fouty.close();//Close the "yellow.txt" file.

    //*****green.txt*****//
    //Create output file stream and open it for green.txt runners (421-480 seconds).
    ofstream foutg("green.txt", ios::out);
    //Output error if file can't open.
    if (foutg.fail()){
        cout << "Error opening file \"green.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 421 && allRunners[i].getPace() <= 480){
            //Add Runner to file "green.txt" if pace is from 421-480 seconds.
            foutg << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    foutg.close();//Close the "green.txt" file.

    //*****orange.txt*****//
    //Create output file stream and open it for orange.txt runners (481-540 seconds).
    ofstream fouto("orange.txt", ios::out);
    //Output error if file can't open.
    if (fouto.fail()){
        cout << "Error opening file \"orange.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 481 && allRunners[i].getPace() <= 540){
            //Add Runner to file "orange.txt" if pace is from 481-540 seconds.
            fouto << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    fouto.close();//Close the "orange.txt" file.

    //*****blue.txt*****//
    //Create output file stream and open it for blue.txt runners (541-600 seconds).
    ofstream foutb("blue.txt", ios::out);
    //Output error if file can't open.
    if (foutb.fail()){
        cout << "Error opening file \"blue.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 541 && allRunners[i].getPace() <= 600){
            //Add Runner to file "blue.txt" if pace is from 361-420 seconds.
            foutb << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    foutb.close();//Close the "blue.txt" file.

    //*****lilac.txt*****//
    //Create output file stream and open it for lilac.txt runners (601-720 seconds).
    ofstream foutl("lilac.txt", ios::out);
    //Output error if file can't open.
    if (foutl.fail()){
        cout << "Error opening file \"lilac.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 601 && allRunners[i].getPace() <= 720){
            //Add Runner to file "lilac.txt" if pace is from 601-720 seconds.
            foutl << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    foutl.close();//Close the "lilac.txt" file.

    //*****red.txt*****//
    //Create output file stream and open it for red.txt runners (721-1200 seconds).
    ofstream foutr("red.txt", ios::out);
    //Output error if file can't open.
    if (foutr.fail()){
        cout << "Error opening file \"red.txt\"!\n";
        return 0;
    }
    for (int i = 0; i < size; i++){
        if (allRunners[i].getPace() >= 721 && allRunners[i].getPace() <= 1200){
            //Add Runner to file "red.txt" if pace is from 721-1200 seconds.
            foutr << allRunners[i].getFirstName() << " " << allRunners[i].getLastName() << " " << allRunners[i].getPace() << endl;
        }
    }
    foutr.close();//Close the "red.txt" file.

    cout << "Done making color teams and adding runners.\n";

    //**********Calculate how many runners are in each color group**********//
    
    //*****white.txt count*****//
    int countWhite = 0;//Create a count variable to count runners.
    //Create input file stream and open it for white.txt runner count
    ifstream finw("white.txt", ios::in);
    if (finw.fail()){
        cout << "Error opening file \"white.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(finw, line)){
        countWhite++;
    }
    finw.close();//Close the "white.txt" file.

    //*****yellow.txt count*****//
    int countYellow = 0;//Create a count variable to count runners.
    //Create input file stream and open it for yellow.txt runner count
    ifstream finy("yellow.txt", ios::in);
    if (finy.fail()){
        cout << "Error opening file \"yellow.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(finy, line)){
        countYellow++;
    }
    finy.close();//Close the "yellow.txt" file.

    //*****green.txt count*****//
    int countGreen = 0;//Create a count variable to count runners.
    //Create input file stream and open it for green.txt runner count
    ifstream fing("green.txt", ios::in);
    if (fing.fail()){
        cout << "Error opening file \"green.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(fing, line)){
        countGreen++;
    }
    fing.close();//Close the "green.txt" file.

    //*****orange.txt count*****//
    int countOrange = 0;//Create a count variable to count runners.
    //Create input file stream and open it for orange.txt runner count
    ifstream fino("orange.txt", ios::in);
    if (fino.fail()){
        cout << "Error opening file \"orange.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(fino, line)){
        countOrange++;
    }
    fino.close();//Close the "orange.txt" file.

    //*****blue.txt count*****//
    int countBlue = 0;//Create a count variable to count runners.
    //Create input file stream and open it for blue.txt runner count
    ifstream finb("blue.txt", ios::in);
    if (finb.fail()){
        cout << "Error opening file \"blue.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(finb, line)){
        countBlue++;
    }
    finb.close();//Close the "blue.txt" file.

    //*****lilac.txt count*****//
    int countLilac = 0;//Create a count variable to count runners.
    //Create input file stream and open it for lilac.txt runner count
    ifstream finl("lilac.txt", ios::in);
    if (finl.fail()){
        cout << "Error opening file \"lilac.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(finl, line)){
        countLilac++;
    }
    finl.close();//Close the "lilac.txt" file.

    //*****red.txt count*****//
    int countRed = 0;//Create a count variable to count runners.
    //Create input file stream and open it for red.txt runner count
    ifstream finr("red.txt", ios::in);
    if (finr.fail()){
        cout << "Error opening file \"red.txt\" for runner count!\n";
        return 0;
    }
    //While not at end of file, count runners in file.
    while (getline(finr, line)){
        countRed++;
    }
    finr.close();//Close the "red.txt" file.

    cout << "Done counting runners in groups.\n";

    //**********Determine starting times**********//

    //Create output file stream and open it for summary.txt.
    ofstream foutsum("summary.txt", ios::out);
    //Output error if file can't open.
    if (foutsum.fail()){
        cout << "Error opening file \"summary.txt\"!\n";
        return 0;
    }
    //Output the amount of runners from each group into the summary.txt file.
    foutsum << "There are " << countWhite << " runners in the white group.\n";
    foutsum << "There are " << countYellow << " runners in the yellow group.\n";
    foutsum << "There are " << countGreen << " runners in the green group.\n";
    foutsum << "There are " << countOrange << " runners in the orange group.\n";
    foutsum << "There are " << countBlue << " runners in the blue group.\n";
    foutsum << "There are " << countLilac << " runners in the lilac group.\n";
    foutsum << "There are " << countRed << " runners in the red group.\n\n";
    
    int hour = 9;
    int minute = 0;
    int second = 0;
    //**White Group**//
    foutsum << "White group will start at 9:00:00 a.m.\n";

    //**Yellow Group**//
    foutsum << "Yellow group will start at ";
    while (countWhite > 0){
        while (countWhite - 60 > 0){
            countWhite -= 60;
            minute++;
        }
        second += countWhite;
        countWhite = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";
    
    //**Green Group**//
    foutsum << "Green group will start at ";
    while (countYellow > 0){
        while (countYellow - 60 > 0){
            countYellow -= 60;
            minute++;
        }
        second += countYellow;
        countYellow = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";

    //**Orange Group**//
    foutsum << "Orange group will start at ";
    while (countGreen > 0){
        while (countGreen - 60 > 0){
            countGreen -= 60;
            minute++;
        }
        second += countGreen;
        countGreen = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";
    
    //**Blue Group**//
    foutsum << "Blue group will start at ";
    while (countOrange > 0){
        while (countOrange - 60 > 0){
            countOrange -= 60;
            minute++;
        }
        second += countOrange;
        countOrange = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";
    
    //**Lilac Group**//
    foutsum << "Lilac group will start at ";
    while (countBlue > 0){
        while (countBlue - 60 > 0){
            countBlue -= 60;
            minute++;
        }
        second += countBlue;
        countBlue = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";
    
    //**Red Group**//
    foutsum << "Red group will start at ";
    while (countLilac > 0){
        while (countLilac - 60 > 0){
            countLilac -= 60;
            minute++;
        }
        second += countLilac;
        countLilac = 0;
    }
    if (second > 60){
        second = second % 60;
        minute++;
    }
    minute++; //Add a minute (60 seconds) to stagger starting groups.
    if (minute >= 60){
        minute = minute % 60;
        hour++;
    }
    if (hour == 12){
        foutsum << hour << ":" << minute << ":" << second << " p.m.\n"; 
    }
    else if(hour > 12){
        foutsum << (hour - 12) << ":" << minute << ":" << second << " p.m.\n";
    }
    else
        foutsum << hour << ":" << minute << ":" << second << " a.m.\n";

    foutsum.close();
    cout << "Done outputting start times.\n";

    return 0;
}
