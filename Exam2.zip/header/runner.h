#ifndef RUNNER_H
#define RUNNER_H

#include <string>
using namespace std;

class Runner
{
private:
    string FirstName;
    string LastName;
    int Pace;
public:
    Runner(string FirstName, string LastName, int Pace);
    string getFirstName() const;
    string getLastName() const;
    int getPace() const;
};

#endif