#include <iostream>
using namespace std;
//I don't know how to get this to work
int *doubleCapacity(const int *list, int& size);

int main(){
    
    int SIZE = 4;
    int * const psize = &SIZE;
    int* list = new int[*psize] {1, 2, 3, 4};

    cout << "The contents of the array are:\n";
    for (int i = 0; i < *psize; i++){
        cout << list[i] << endl;
    }
    cout << "Size is: " << *psize << endl;
    
    doubleCapacity(list , *psize);
    cout << "The contents of the array are:\n";
    for (int i = *psize/2; i < *psize; i++){
        list[i] = 0;
    }

    for (int i = 0; i < *psize; i++){
        cout << list[i] << endl;
    }
    cout << "Size is: " << *psize << endl;

    return 0;
}

*doubleCapacity(const int *list, int& size){
    int s = size * 2;
    int* list2 = new int[s];
    for (int i = 0; i < size; i++){
        list2[i] = list[i];
    }
    for (int i = size; i < s; i++){
        list2[i] = 0;
    }
    size = s;
    delete [] list2;
    return list2;
}