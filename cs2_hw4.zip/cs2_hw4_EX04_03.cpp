#include <iostream>
using namespace std;

int smallest(int *location, int *size);

int main(){

    int size = 8;
    int array[size] = {1, 2, 4, 5, 10, 100, 2, -22};
    int *psize = &size;
    int *parray = &array[0];
    cout << "The smallest number of the array is: " << smallest(parray, psize) << endl;

    return 0;
}

smallest(int *location, int *size){
    int least = *location;
    for (int i = 0; i < *size; i++){
        if (*(location + i) < least)
            least = *(location + i);
    }
    return least;
}