#include "course.h"
#include <iostream>
#include <string>
using namespace std;

int main() {

    Course c1("Test1", 2);
    cout << "The capacity of c1 is: " << c1.getCapacity() << endl << endl;
    c1.addStudent("Peter Griffin");
    c1.addStudent("Stewie Griffin");
    c1.addStudent("Michael Meyers");

    cout << "The students in c1 are: \n";
    for (int i = 0; i < c1.getNumberOfStudents(); i++){
        cout << c1.getStudents()[i] << endl;
    }
    cout << endl;
    cout << "The capacity of c1 is: " << c1.getCapacity() << endl << endl;
    
    c1.dropStudent("Michael Meyers");
    cout << "The students in c1 are:\n";
    for (int i = 0; i < c1.getNumberOfStudents(); i++){
        cout << c1.getStudents()[i] << endl;
    }
    cout << endl;

    return 0;
}