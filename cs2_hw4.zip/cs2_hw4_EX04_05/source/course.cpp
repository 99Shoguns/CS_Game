#include <iostream>
#include <string>
#include "course.h"
using namespace std;

Course::Course(const string& courseName, int capacity)
{
    numberOfStudents = 0;
    this->courseName = courseName;
    this->capacity = capacity;
    students = new string[capacity];
}
Course::Course(const Course& course)
{
    courseName = course.courseName;
    numberOfStudents = course.numberOfStudents;
    capacity = course.capacity;
    students = new string[capacity];
}
Course::~Course()
{
    delete [] students;
}
string Course::getCourseName() const
{
    return courseName;
}
int Course::getCapacity() const
{
    return capacity;
}
void Course::addStudent(const string& name)
{
    if (numberOfStudents == capacity){
        capacity *= 2;
        students2 = new string[capacity];
        for (int i = 0; i < numberOfStudents; i++){
            students2[i] = students[i];
        }
        delete [] students;
        students = new string[capacity];
        for (int i = 0; i < numberOfStudents; i++){
            students[i] = students2[i];
        }
        delete [] students2;
        students[numberOfStudents] = name;
        numberOfStudents++;
    }
    else
        students[numberOfStudents] = name;
        numberOfStudents++;
}
void Course::dropStudent(const string& name)
{
    int studentIndex;
    for (int i = 0; i < numberOfStudents; i++){
        if(students[i] == name)
            studentIndex = i;
    }
    for (int i = studentIndex; i < numberOfStudents -1; i++){
        students[i] = students[i+1];
    }
    students[numberOfStudents] = "";
    numberOfStudents--;
}
string* Course::getStudents() const
{
    return students;
}
int Course::getNumberOfStudents() const
{
    return numberOfStudents;
}
void Course::clear()
{
    students = NULL;
}