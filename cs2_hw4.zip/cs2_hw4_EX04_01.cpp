#include <iostream>
using namespace std;

int main(){
    int size;
    cout << "This program will determine the average of given numbers.\n";
    cout << "Please input how many numbers you want: ";
    cin >> size;
    //Make pointer to reference size.
    const int * const s = &size;
    
    //Make and give values for a temporary pointer array.
    int *x;
    x = new int[*s];
    int number = 1;
    int input;
    for (int i = 0; i < *s; i++){
        cout << "Please input value for #" << number << endl;
        cin >> input;
        x[i] = input;
        number++;
    }
    //Output the numbers given.
    cout << "Your values are: ";
    for (int i = 0; i < *s; i++){
        if (i < *s-1)
            cout << x[i] << ", ";
        else
            cout << x[i] << ".\n";
    }
    //Output the average of the numbers.
    int average = 0;
    for (int i = 0; i < *s; i++){
        average += x[i];
    }
    average /= *s;
    cout << "The average of the numbers given is: " << average << endl;
    //Output how many numbers are greater than the average.
    int above = 0;
    for (int i = 0; i < *s; i++){
        if (x[i] > average)
            above++;
    }
    if (above == 0)
        cout << "There are no numbers above the average.\n";
    else if (above == 1)
        cout << "There is one number above the average.\n";
    else
        cout << "There are " << above << " numbers above the average.\n";
    
    delete[] x;

    return 0;
}