#ifndef RECTANGLE2D_H
#define RECTANGLE2D_H

class Rectangle2D
{
private:
    double x;
    double y;
    double width;
    double height;
public:
    Rectangle2D();
    Rectangle2D(double a, double b, double Width, double Height);
    double getX() const;
    void setX(double a);
    double getY() const;
    void setY(double y);
    double getWidth() const;
    void setWidth(double Width);
    double getHeight() const;
    void setHeight(double Height);
    double getArea() const;
    double getPerimeter() const;
    bool contains(double xcoord, double ycoord) const;
    bool contains(const Rectangle2D &r) const;
    bool overlaps(const Rectangle2D &r) const;
};

#endif