#include "rectangle2D.h"
#include <iostream>
using namespace std;

//Constructors
Rectangle2D::Rectangle2D()
{
    x = 0;
    y = 0;
    width = 1;
    height = 1;
}
Rectangle2D::Rectangle2D(double a, double b, double Width, double Height)
{
    x = a;
    y = b;
    width = Width;
    height = Height;
}
//Get and Set functions for rectangle data
double Rectangle2D::getX() const
{
    return x;
}
void Rectangle2D::setX(double a)
{
    x = a;
}
double Rectangle2D::getY() const
{
    return y;
}
void Rectangle2D::setY(double b)
{
    y = b;
}
double Rectangle2D::getWidth() const
{
    return width;
}
void Rectangle2D::setWidth(double Width)
{
    width = Width;
}
double Rectangle2D::getHeight() const
{
    return height;
}
void Rectangle2D::setHeight(double Height)
{
    height = Height;
}
//Get functions for rectangle detailed information
double Rectangle2D::getArea() const
{
    return (width * height);
}
double Rectangle2D::getPerimeter() const
{
    return ((2 * width) + (2 * height));
}
//Check function for containment and overlap of points and rectangles
bool Rectangle2D::contains(double xcoord, double ycoord) const
{
    double leftx, rightx, topy, bottomy;
    //Set left and right x
    if (x < 0){ //if x is negative
        leftx = -1 * (x - (0.5 * width));
        rightx = -1 * (x + (0.5 * width));
    }
    else {
        leftx = x - (0.5 * width);
        rightx = x + (0.5 * width);
    }
    //Set top and bottom y
    if (y < 0) { //if y is negative
        topy = -1 * (y + (0.5 * height));
        bottomy = -1 * (y - (0.5 * height));
    }
    else {
        topy = y + (0.5 * height);
        bottomy = y - (0.5 * height);
    }
    //Determine if given (x,y) is within rectangle
    if ((xcoord > leftx && xcoord < rightx) && (ycoord > bottomy && ycoord < topy) )
        return true;
    else
        return false; 
}
bool Rectangle2D::contains(const Rectangle2D &r) const
{
    ///////////R1///////////
    //Get x, y, width, and height for r1 (to see if r1 contains r2)
    double r1x = x;
    double r1y = y;
    double r1width = width;
    double r1height = height;
    double r1leftx, r1rightx, r1topy, r1bottomy;
    //Set r1 left and right x
    if (r1x < 0){ //if x is negative
        r1leftx = -1 * (r1x - (0.5 * r1width));
        r1rightx = -1 * (r1x + (0.5 * r1width));
    }
    else {
        r1leftx = r1x - (0.5 * r1width);
        r1rightx = r1x + (0.5 * r1width);
    }
    //Set r1 top and bottom y
    if (r1y < 0) { //if y is negative
        r1topy = -1 * (r1y + (0.5 * r1height));
        r1bottomy = -1 * (r1y - (0.5 * r1height));
    }
    else {
        r1topy = r1y + (0.5 * r1height);
        r1bottomy = r1y - (0.5 * r1height);
    }
    
    ///////////R2///////////
    //Get x, y, width, and height for r2 (&r);
    double r2x = r.getX();
    double r2y = r.getY();
    double r2width = r.getWidth();
    double r2height = r.getHeight();
    double r2leftx, r2rightx, r2topy, r2bottomy;
    //Set left and right x
    if (r2x < 0){ //if x is negative
        r2leftx = -1 * (r2x - (0.5 * r2width));
        r2rightx = -1 * (r2x + (0.5 * r2width));
    }
    else {
        r2leftx = r2x - (0.5 * r2width);
        r2rightx = r2x + (0.5 * r2width);
    }
    //Set top and bottom y
    if (r2y < 0) { //if y is negative
        r2topy = -1 * (r2y + (0.5 * r2height));
        r2bottomy = -1 * (r2y - (0.5 * r2height));
    }
    else {
        r2topy = r2y + (0.5 * r2height);
        r2bottomy = r2y - (0.5 * r2height);
    }
    //Determine if R1 contains the referenced R2
    if ( (r2leftx > r1leftx && r2rightx < r1rightx) && (r2topy < r1topy && r2bottomy > r1bottomy) )
        return true;
    else
        return false;
}
bool Rectangle2D::overlaps(const Rectangle2D &r) const
{
    ///////////R1///////////
    //Get x, y, width, and height for r1 (to see if r1 contains r2)
    double r1x = x;
    double r1y = y;
    double r1width = width;
    double r1height = height;
    double r1leftx, r1rightx, r1topy, r1bottomy;
    //Set r1 left and right x
    if (r1x < 0){ //if x is negative
        r1leftx = -1 * (r1x - (0.5 * r1width));
        r1rightx = -1 * (r1x + (0.5 * r1width));
    }
    else {
        r1leftx = r1x - (0.5 * r1width);
        r1rightx = r1x + (0.5 * r1width);
    }
    //Set r1 top and bottom y
    if (r1y < 0) { //if y is negative
        r1topy = -1 * (r1y + (0.5 * r1height));
        r1bottomy = -1 * (r1y - (0.5 * r1height));
    }
    else {
        r1topy = r1y + (0.5 * r1height);
        r1bottomy = r1y - (0.5 * r1height);
    }
    
    ///////////R2///////////
    //Get x, y, width, and height for r2 (&r);
    double r2x = r.getX();
    double r2y = r.getY();
    double r2width = r.getWidth();
    double r2height = r.getHeight();
    double r2leftx, r2rightx, r2topy, r2bottomy;
    //Set left and right x
    if (r2x < 0){ //if x is negative
        r2leftx = -1 * (r2x - (0.5 * r2width));
        r2rightx = -1 * (r2x + (0.5 * r2width));
    }
    else {
        r2leftx = r2x - (0.5 * r2width);
        r2rightx = r2x + (0.5 * r2width);
    }
    //Set top and bottom y
    if (r2y < 0) { //if y is negative
        r2topy = -1 * (r2y + (0.5 * r2height));
        r2bottomy = -1 * (r2y - (0.5 * r2height));
    }
    else {
        r2topy = r2y + (0.5 * r2height);
        r2bottomy = r2y - (0.5 * r2height);
    }
    //Check to see if the two rectangles overlap
    //If one of the corners is within a different rectangle
    if ( /*r2 left x*/((r2leftx > r1leftx && r2leftx < r1rightx) || /*r2 right x*/(r2rightx > r1leftx && r2rightx < r1rightx))/*&&*/ && /*r2 top y*/(r2topy < r1topy && r2topy > r1bottomy) || (r2bottomy < r1topy && r2bottomy > r1bottomy) )
        return true;
    //If one of the corners is NOT within a different rectangle
    else if (/*Y AXIS ONLY OVERLAP*/ /*r2 left x*/((r2leftx > r1leftx && r2leftx < r1rightx) || /*r2 right x*/(r2rightx > r1leftx && r2rightx < r1rightx)) && (/*r2 Y axis*/(r2topy > r1topy && r2bottomy < r1bottomy))/*||*/ || /*X AXIS ONLY OVERLAP*/ (/*r2 top y*/(r2topy < r1topy && r2topy > r1bottomy) || (r2bottomy < r1topy && r2bottomy > r1bottomy)) && (r2leftx < r1leftx && r2rightx > r1rightx)  )
        return true;
    else
        return false;
}