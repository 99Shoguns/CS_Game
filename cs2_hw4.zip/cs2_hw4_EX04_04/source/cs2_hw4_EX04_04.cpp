#include "rectangle2D.h"
#include <iostream>
using namespace std;

int main(){

    Rectangle2D r1(2, 2, 5.5, 4.9);
    Rectangle2D r2(4, 5, 10.5, 3.2);
    Rectangle2D r3(3, 5, 2.3, 5.4);

    cout << "The area for r1 is: " << r1.getArea() << endl;
    cout << "The perimeter for r1 is: " << r1.getPerimeter() << endl;
    
    cout << "r1 ";
    if (r1.contains(3, 3))
        cout << "contains";
    else
        cout << "does not contain";
    cout << " (3, 3).\n";
    
    cout << "r1 ";
    if (r1.contains(r2))
        cout << "contains";
    else
        cout << "does not contain";
    cout << " r2.\n";

    cout << "r1 ";
    if (r1.overlaps(r3))
        cout << "overlaps";
    else
        cout << "does not overlap";
    cout << " r3.\n";

    return 0;
}