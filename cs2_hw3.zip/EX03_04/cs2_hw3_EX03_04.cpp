//Liang 10.4: Sort characters in a string
#include <iostream>
#include <string>
using namespace std;

string sort(string& s);

int main(){

    //Get a string from user
    string str1;
    cout << "Please enter a string: ";
    cin >> str1;

    cout << "Your sorted string is: " << sort(str1); 

    return 0;
}

string sort(string& s){
    //Get string length and make an array of that size.
    string str1;
    int strSize;
    strSize = s.length();
    char strChars[strSize];
    char modstrChars[strSize];
    //Assign string indexes to the array's equivilant indexes
    for (int i = 0; i < strSize; i++){
        strChars[i] = s.at(i);
        modstrChars[i] = s.at(i);
    }
    int index = strSize - 1;
    int l, a, k, m;
    int g, h;
    while (l != -1){
        l = 0;
        a = 0;
        for (int c = 0; c < strSize; c++){
            k = 0;
            for (int j = 1; j < index; j++){
                if (modstrChars[j] <= modstrChars[k]){
                    g = modstrChars[j];
                    h = modstrChars[k];
                    modstrChars[k] = g;
                    modstrChars[j] = h;
                    k++;
                }
            }
        }
        h = modstrChars[index];
        if (modstrChars[0] >= h)
            a = modstrChars[index];
            m = index - 1;
            for (int i = index; i > 1; i--){
                modstrChars[i] = modstrChars[m];
                m--;
            }
            modstrChars[0] = a;
        l = -1; 
    }
    //Output the array
    for (int x = 0; x < strSize; x++){
        s += modstrChars[x];
    }
    str1 = s;
    return str1;
}
