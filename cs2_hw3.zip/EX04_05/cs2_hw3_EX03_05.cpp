//Liang 10.10: the MyInteger class
#include <iostream>
#include <sstream>
#include <string>
#include "myInteger.h"
using namespace std;

int main(){

    MyInteger num(20);
    cout << num.getValue() << endl;
    cout << num.isEven() << endl;
    cout << num.isOdd() << endl;
    cout << num.isPrime() << endl;
    cout << num.isEven(20) << endl;
    cout << num.isOdd(20) << endl;
    cout << num.isPrime(20) << endl;
    cout << num.isEven(20) << endl;
    cout << num.isOdd(20) << endl;
    cout << num.isPrime(20) << endl;
    cout << num.equals(20) << endl;
    cout << num.equals(20) << endl;
    string s = "This is my String.";
    cout << num.parseInt(s) << endl;

    return 0;
}