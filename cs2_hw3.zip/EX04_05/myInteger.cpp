#include <iostream>
#include <sstream>
#include <string>
#include "myInteger.h"
using namespace std;



MyInteger::MyInteger(int num){
    Value = num;
}
int MyInteger::getValue() const{
    return Value;
}
bool MyInteger::isEven() const{
    if (Value % 2 == 0)
        return true;
    else
        return false;
}
bool MyInteger::isOdd() const{
    if (Value % 2 != 0)
        return true;
    else
        return false;
}
bool MyInteger::isPrime() const{
    int half = Value / 2;
    for (int i = 2; i <= half; i++){//Retreived Prime formula from stack overflow
        if (Value % i == 0)//at "https://www.javatpoint.com/prime-number-program-in-cpp"
            return true;
        else
            return false;
    }
}//I don't know why it won't accept this line
bool MyInteger::isEven(int num){
    if (num % 2 == 0)
        return true;
    else
        return false;
}
bool MyInteger::isOdd(int num){
    if (num % 2 != 0)
        return true;
    else
        return false;
}
bool MyInteger::isPrime(int num){
    int half = num / 2;
    for (int i = 2; i <= half; i++){
        if (num % i == 0)
            return true;
        else
            return false;
    }
}//I don't know why it won't accept this line
bool MyInteger::isEven(const MyInteger& n){
    if (n % 2 == 0) //I don't know why it won't accept this line
        return true;
    else
        return false;
}//I don't know why it won't accept this line
bool MyInteger::isOdd(const MyInteger& n){
    int j = n;//I don't know why it won't accept this line
    if (n % 2 != 0)//I don't know why it won't accept this line
        return true;
    else
        return false;
}//I don't know why it won't accept this line
bool MyInteger::isPrime(const MyInteger& n){
    int half = n / 2;//I don't know why it won't accept this line
    for (int i = 2; i <= half; i++){
        if (n % i == 0)//I don't know why it won't accept this line
            return true;
        else
            return false;
}
bool MyInteger::equals(int num) const{//I don't know why it won't accept this line
    if (Value = num)
        return true;
    else
        return false;
}
bool MyInteger::equals(const MyInteger& n) const{//I don't know why it won't accept this line
    if (Value = n)
        return true;
    else
        return false;
}
static int MyInteger::parseInt(const string& s){//I don't know why it won't accept this line
    stringstream ss(s);
    string part;
    while (!ss.eof()){
        ss >> part;
        cout << part << endl;
    }
}//I don't know why it won't accept this line