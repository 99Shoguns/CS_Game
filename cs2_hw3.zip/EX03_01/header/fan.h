#ifndef FAN_H
#define FAN_H

#include <iostream>
using namespace std;

class Fan
{
private:
    int Speed; //Speeds of 1, 2, or 3.
    bool On; //Fan on or off?
    double Radius; //Fan turn radius.

public:
    Fan();
    //Get accessors
    int getSpeed();
    bool getOn();
    double getRadius();
    //Set mutators
    void setSpeed(int speed);
    void setOn(bool on);
    void setRadius(int radius);
    //Get ALL accessors
    void Specs();
};

#endif