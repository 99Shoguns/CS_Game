#ifndef FANCPP_H
#define FANCPP_H

#include <iostream>
#include "fan.h"
using namespace std;

Fan::Fan(){
    Speed = 1;
    On = false;
    Radius = 5;
}
//Get accessors
int Fan::getSpeed(){
    return Speed;
}
bool Fan::getOn(){
    return On;
}
double Fan::getRadius(){
    return Radius;
}
//Set mutators
void Fan::setSpeed(int speed){
    if (speed >=1 && speed <=3)
        Speed = speed;
}
void Fan::setOn(bool on){
    On = on;
}
void Fan::setRadius(int radius){
    if (radius > 0)
        Radius = radius;
}
//Get ALL accessors
void Fan::Specs(){
    cout << "Speed: " << getSpeed() << endl;
    cout << "On: " << getOn() << endl;
    cout << "Radius: " << getRadius() << endl;
}

#endif