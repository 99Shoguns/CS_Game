//Liang Exercise 9.2: the Fan class
//*********************************
//I followed the walkthrough video on the Liang companion website.
//*********************************
#include <iostream>
#include "fan.h"
using namespace std;

int main(){

    Fan fan1;
    fan1.setSpeed(3);
    fan1.setOn(true);
    fan1.setRadius(10);

    Fan fan2;
    fan2.setSpeed(2);
    fan2.setOn(false);
    fan2.setRadius(5);

    cout << "The specs for fan1 are: \n";
    fan1.Specs();
    cout << endl;
    cout << "The specs for fan2 are: \n";
    fan2.Specs();
    cout << endl;

    return 0;
}


