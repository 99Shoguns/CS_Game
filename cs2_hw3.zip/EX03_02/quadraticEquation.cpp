#include <iostream>
#include <cmath>
#include "quadraticEquation.h"
using namespace std;

QuadraticEquation::QuadraticEquation(){
    a = 1;
    b = 1;
    c = 1;
}
//set mutators.
void QuadraticEquation::seta(int num1){
    if (a != 0)
        a = num1;
}
void QuadraticEquation::setb(int num2){
    b = num2;
}
void QuadraticEquation::setc(int num3){
    c = num3;
}
//get accessors.
int QuadraticEquation::geta(){
    return a;
}
int QuadraticEquation::getb(){
    return b;
}
int QuadraticEquation::getc(){
    return c;
}
int QuadraticEquation::getDiscriminant(){ //b^2 - 4ac
    return ( (pow(b,2)) - (4 * (a * c)) );
}
//Root formula:
//       -b +/- sqrt(b^2 - 4ac)
// root= -------------------------
//                 2a
int QuadraticEquation::getRoot1(){ //the 'x' in "ax^2" (the + forumla)
    if (getDiscriminant() >= 0) 
        return ( ( (b * -1) + (sqrt(getDiscriminant())) ) / (2 * a) );
    else
        return 0;
}
int QuadraticEquation::getRoot2(){ //the 'x' in "bx" (the - formula)
    if (getDiscriminant() >= 0)  
        return ( ( (b * -1) - (sqrt(getDiscriminant())) ) / (2 * a) );
    else
        return 0;
}
void QuadraticEquation::answer(){//cout the answer(s).
    if (getDiscriminant() > 0){
        cout << "Root 1: " << getRoot1() << endl;

        cout << "Root 2: " << getRoot2() << endl;

    }
    else if (getDiscriminant() == 0)
        cout << "The only root is: " << getRoot1() << ".\n";

    else
        cout << "The equation has no real roots.\n";
}
