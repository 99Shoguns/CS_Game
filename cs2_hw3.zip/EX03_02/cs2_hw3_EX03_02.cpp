//Liang 9.6- Algebra: quadratic equations
#include <iostream>
#include <cmath>
#include "quadraticEquation.h"
using namespace std;

int main(){

    int num1, num2, num3;
    //cout the quadratic equation
    cout << "The quadratic equation is ax^2 + bx + c = 0.\n";
    //Get user input for a, b, and c
    cout << "Please input three numbers for a, b, and c: \n";
    cout << "a: ";
    cin >> num1;
    while (num1 == 0){
        cout << "'a' can't be 0. Please enter a new number.\n";
        cin >> num1;
    }
    cout << "b: ";
    cin >> num2;
    cout << "c: ";
    cin >> num3;

    cout << "Your quadratic equation is: " << num1 << "x^2 + " << num2 << "x + " << num3 << " = 0.\n";

    QuadraticEquation quad1;
    quad1.seta(num1);
    quad1.setb(num2);
    quad1.setc(num3);
    quad1.answer();

    return 0;
}