#ifndef QUADRATICEQUATION_H
#define QUADRATICEQUATION_H

#include <iostream>
using namespace std;

class QuadraticEquation //ax^2 + bx + x = 0
{
private:
    int a;
    int b;
    int c;
public:
    QuadraticEquation();
//get accessors for a, b, and c
    int geta();
    int getb();
    int getc();
//set mutators for a, b, and c
    void seta(int num1);
    void setb(int num2);
    void setc(int num3);
//Math functions
    int getDiscriminant(); //b^2 - 4ac
    //Root formula:
    //       -b +/- sqrt(b^2 - 4ac)
    // root= -------------------------
    //                 2a
    int getRoot1(); //the 'x' in "ax^2" (the + forumla)
    int getRoot2(); //the 'x' in "bx" (the - formula)
    void answer(); //cout the answer.
};

#endif