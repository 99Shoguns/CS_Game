#include <iostream>
#include "evenNumber.h"
using namespace std;

EvenNumber::EvenNumber(){
    Value = 0;
}
EvenNumber::EvenNumber(int number){
    if (number % 2 == 0)
        Value = number;
}
int EvenNumber::getValue(){
    return Value;
}
void EvenNumber::setValue(int number){
    Value = number;
}
EvenNumber EvenNumber::getNext(){
    cout << getValue() + 2 << endl;
    return getValue() + 2;
}
EvenNumber EvenNumber::getPrevious(){
    cout << getValue() - 2 << endl;
    return getValue() - 2;
}