#ifndef EVENNUMBER_H
#define EVENNUMBER_H

class EvenNumber
{
private:
    int Value;
public:
    EvenNumber();
    EvenNumber(int);
    int getValue();
    void setValue(int);
    EvenNumber getNext();
    EvenNumber getPrevious();
};

#endif