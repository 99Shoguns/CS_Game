//Liang 9.11: the EvenNumber class
#include <iostream>
#include "evenNumber.h"
using namespace std;

int main(){

    EvenNumber num1(16);
    cout << "The current value of num1 is: " << num1.getValue() << endl;
    cout << "The next value of num1 is: ";
    num1.getNext();
    cout << "The previous value of num1 is: ";
    num1.getPrevious();

    return 0;
}